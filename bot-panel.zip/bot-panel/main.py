"""
Bot Panel - Decky Loader backend.

Talks to the control panel that DeckBot or PumpBot runs on this Deck (127.0.0.1 only). The
panel token is read from the bot's own data folder, so the Quick Access menu never has to
handle it, and the browser never talks to the bot directly.
"""

import asyncio
import json
import os
import urllib.error
import urllib.request

import decky

BOTS = ("deckbot", "pumpbot")
DEFAULT_SETTINGS = {"bot": "auto"}


def _home():
    # Decky runs as root; the bots live in the Deck user's home folder.
    return getattr(decky, "DECKY_USER_HOME", None) or os.environ.get("DECKY_USER_HOME") or "/home/deck"


def _panel_file(bot):
    return os.path.join(_home(), bot, "data", "panel.json")


def _read_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def _installed_bots():
    return [b for b in BOTS if _read_json(_panel_file(b))]


def _settings_path():
    return os.path.join(decky.DECKY_PLUGIN_SETTINGS_DIR, "settings.json")


def _load_settings():
    s = dict(DEFAULT_SETTINGS)
    s.update(_read_json(_settings_path()) or {})
    return s


def _save_settings(s):
    os.makedirs(os.path.dirname(_settings_path()), exist_ok=True)
    with open(_settings_path(), "w") as f:
        json.dump(s, f, indent=2)


def _call(bot, method, path, body=None):
    """Blocking HTTP call to a bot's panel. Returns (status, parsed_json)."""
    info = _read_json(_panel_file(bot))
    if not info:
        return 0, {"error": f"{bot} isn't set up on this Deck."}
    url = f"http://127.0.0.1:{int(info.get('port', 8765))}{path}"
    headers = {"Authorization": f"Bearer {info.get('token', '')}"}
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            return resp.status, json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b"{}")
        except json.JSONDecodeError:
            return e.code, {"error": "The bot sent an unreadable reply."}
    except (urllib.error.URLError, OSError, TimeoutError):
        return 0, {"error": f"{bot} isn't running right now."}


class Plugin:
    async def get_state(self):
        """Every installed bot's state, read in parallel. Each bot is shown even if it's not running."""
        installed = _installed_bots()
        if not installed:
            return {"bots": {}, "selected": None,
                    "error": "No bot found. Set up DeckBot or PumpBot first, then start it."}
        results = await asyncio.gather(*(asyncio.to_thread(_call, b, "GET", "/api/state?siblings=0")
                                         for b in installed))
        bots = {}
        for name, (status, body) in zip(installed, results):
            if status == 200:
                bots[name] = {"state": body, "error": None}
            else:
                bots[name] = {"state": None, "error": body.get("error", "Could not reach the bot.")}
        sel = _load_settings()["bot"]
        selected = sel if sel in installed else installed[0]
        return {"bots": bots, "selected": selected, "error": None}

    async def set_bot(self, name):
        s = _load_settings()
        s["bot"] = name if name in BOTS else "auto"
        _save_settings(s)
        return s

    async def act(self, bot, action, value=None, confirm=None):
        if bot not in _installed_bots():
            return {"ok": False, "message": f"{bot} isn't set up on this Deck."}
        body = {"action": action}
        if value is not None:
            body["value"] = value
        if confirm is not None:
            body["confirm"] = confirm
        status, reply = await asyncio.to_thread(_call, bot, "POST", "/api/action", body)
        if status == 0:
            return {"ok": False, "message": reply.get("error", "Couldn't reach the bot.")}
        return {"ok": bool(reply.get("ok")), "message": reply.get("message") or reply.get("error", "")}

    async def _main(self):
        decky.logger.info("Bot Panel loaded")

    async def _unload(self):
        decky.logger.info("Bot Panel unloaded")

    async def _uninstall(self):
        pass
