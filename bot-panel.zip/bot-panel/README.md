# Bot Panel (Decky plugin)

Adds DeckBot or PumpBot to the Steam Deck **Quick Access** menu, so you can check and steer it in Game Mode.

**What it shows:** mode (paper or live), balance or equity, today's and total profit, open positions,
and whether the bot is paused or has hit its daily limit.

**What you can do:** change risk level (conservative, moderate, aggressive), change trade size
(PumpBot), pause or resume new buys, switch back to paper mode, and sell everything and stop
(asks you to confirm first).

**What it doesn't do:** going live needs you to type `GO LIVE`, which is awkward with a controller,
so do that from the bot's web dashboard or terminal.

## Requirements
- DeckBot or PumpBot installed and running on this Deck (it reads the panel the bot runs).
- Decky Loader.

## Install
Install the zip from Decky's settings (developer mode, install plugin from zip), then open Quick Access.
If both bots are installed, pick one in the first menu item.

The panel only listens on this Deck (127.0.0.1). The token is read from the bot's own data folder;
this plugin never sends it anywhere else.
