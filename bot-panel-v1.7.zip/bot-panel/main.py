"""
Bot Panel - Decky Loader backend.

Talks to the control panel that DeckBot or PumpBot runs on this Deck (127.0.0.1 only). The
panel token is read from the bot's own data folder, so the Quick Access menu never has to
handle it, and the browser never talks to the bot directly.
"""

import asyncio
import json
import os
import re
import time
from datetime import datetime, timezone
import urllib.error
import urllib.request

import decky

BOTS = ("deckbot", "pumpbot")
PLUGIN_VERSION = "1.7.0"
LOG_FILES = {"deckbot": "deckbot.log", "pumpbot": "pumpbot.log"}
_LOG_RX = re.compile(r"^(\d{4}-\d\d-\d\d) (\d\d:\d\d):\d\d (\w+) (.*)$")
_REDACT = [
    (re.compile(r"-----BEGIN[^-]*-----.*?(-----END[^-]*-----|$)"), "***"),
    (re.compile(r"(api[-_]?key[=:]\s*)[^&\s\"',]+", re.I), r"\1***"),
    (re.compile(r"(secret|private[-_]?key|password)([\"']?\s*[=:]\s*[\"']?)[^\s\"',]+", re.I), r"\1\2***"),
    (re.compile(r"\b[1-9A-HJ-NP-Za-km-z]{64,}\b"), "***"),
]


def _power():
    """{'on_battery': bool|None, 'percent': int|None} from the Deck's battery and charger."""
    base = "/sys/class/power_supply"

    def rd(p):
        try:
            with open(p) as f:
                return f.read().strip()
        except OSError:
            return None
    plugged, pct, status = False, None, None
    try:
        names = os.listdir(base)
    except OSError:
        return {"on_battery": None, "percent": None}
    for n in names:
        t = rd(os.path.join(base, n, "type"))
        if t in ("Mains", "USB", "USB_PD", "USB_C") and rd(os.path.join(base, n, "online")) == "1":
            plugged = True
        elif t == "Battery":
            c = rd(os.path.join(base, n, "capacity"))
            pct = int(c) if c and c.isdigit() else pct
            status = rd(os.path.join(base, n, "status")) or status
    if pct is None:
        return {"on_battery": None, "percent": None}
    return {"on_battery": not plugged and status not in ("Charging", "Full"), "percent": pct}


def _tail_log(bot, n=100):
    """Reads the bot's log directly - used only for bot versions whose panel doesn't send it."""
    path = os.path.join(_home(), bot, "data", LOG_FILES.get(bot, bot + ".log"))
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - 64 * 1024))
            lines = f.read().decode("utf-8", "replace").splitlines()
    except OSError:
        return []
    if size > 64 * 1024:
        lines = lines[1:]
    out = []
    for ln in lines:
        m = _LOG_RX.match(ln)
        if m:
            text = m.group(4)
            for rx, sub in _REDACT:
                text = rx.sub(sub, text)
            out.append({"date": m.group(1), "time": m.group(2), "level": m.group(3), "text": text})
    return out[-n:]
CHECK_EVERY = {"deckbot": 300, "pumpbot": 10}  # how often each bot records a market check (seconds)


def _ago(seconds):
    m = int(seconds // 60)
    if m < 1:
        return "just now"
    if m < 60:
        return f"{m} min ago"
    return f"{m // 60} h {m % 60} min ago"


def _health(last_check_iso, interval):
    """Same rule as the bots' own panel, so older bot versions still get a status line."""
    try:
        ts = datetime.fromisoformat(str(last_check_iso).replace("Z", "+00:00"))
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        age = max(0.0, time.time() - ts.timestamp())
    except (TypeError, ValueError):
        return {"status": "starting", "text": "Starting up · no market check yet"}
    if age <= max(3 * interval + 60, 120):
        return {"status": "running", "text": f"Running · last check {_ago(age)}"}
    return {"status": "stale", "text": f"No market check for {_ago(age).replace(' ago', '')} · may be stuck, check the logs"}
DEFAULT_SETTINGS = {"bot": "auto", "toasts": True}


def _home():
    # Decky runs as root; the bots live in the Deck user's home folder.
    return getattr(decky, "DECKY_USER_HOME", None) or os.environ.get("DECKY_USER_HOME") or "/home/deck"


def _panel_file(bot):
    return os.path.join(_home(), bot, "data", "panel.json")


def _read_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def _installed_bots():
    return [b for b in BOTS if _read_json(_panel_file(b))]


def _settings_path():
    return os.path.join(decky.DECKY_PLUGIN_SETTINGS_DIR, "settings.json")


def _load_settings():
    s = dict(DEFAULT_SETTINGS)
    s.update(_read_json(_settings_path()) or {})
    return s


def _save_settings(s):
    os.makedirs(os.path.dirname(_settings_path()), exist_ok=True)
    with open(_settings_path(), "w") as f:
        json.dump(s, f, indent=2)


def _call(bot, method, path, body=None, timeout=None):
    """Blocking HTTP call to a bot's panel. Returns (status, parsed_json)."""
    info = _read_json(_panel_file(bot))
    if not info:
        return 0, {"error": f"{bot} isn't set up on this Deck."}
    url = f"http://127.0.0.1:{int(info.get('port', 8765))}{path}"
    headers = {"Authorization": f"Bearer {info.get('token', '')}"}
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout or (45 if method == "POST" else 8)) as resp:
            return resp.status, json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b"{}")
        except json.JSONDecodeError:
            return e.code, {"error": "The bot sent an unreadable reply."}
    except (urllib.error.URLError, OSError, TimeoutError):
        return 0, {"error": f"{bot} isn't running right now."}


class Plugin:
    async def get_state(self):
        """Every installed bot's state, read in parallel. Each bot is shown even if it's not running."""
        installed = _installed_bots()
        if not installed:
            return {"bots": {}, "selected": None,
                    "error": "No bot found. Set up DeckBot or PumpBot first, then start it."}
        results = await asyncio.gather(*(asyncio.to_thread(_call, b, "GET", "/api/state?siblings=0")
                                         for b in installed))
        bots = {}
        for name, (status, body) in zip(installed, results):
            if status == 200:
                if not body.get("health"):
                    body["health"] = _health(body.get("updated"), CHECK_EVERY.get(name, 300))
                if "log" not in body:
                    body["log"] = await asyncio.to_thread(_tail_log, name)
                bots[name] = {"state": body, "error": None}
            else:
                bots[name] = {"state": None, "error": body.get("error", "Could not reach the bot.")}
        sel = _load_settings()["bot"]
        selected = sel if sel in installed else installed[0]
        return {"bots": bots, "selected": selected, "error": None, "version": PLUGIN_VERSION, "power": _power()}

    async def get_settings(self):
        return _load_settings()

    async def set_toasts(self, on):
        s = _load_settings()
        s["toasts"] = bool(on)
        _save_settings(s)
        return s

    async def dashboard_url(self, bot):
        """The bot's own dashboard link (with its private token), to open in Steam's browser."""
        if bot not in BOTS:
            return None
        info = _read_json(_panel_file(bot))
        if not info or not info.get("token"):
            return None
        return f"http://127.0.0.1:{int(info.get('port', 8765))}/#t={info['token']}"

    async def find_key_files(self):
        """Coinbase key files (cdp_api_key.json) in Downloads, Desktop or the home folder."""
        home = _home()
        found = []
        for folder in (os.path.join(home, "Downloads"), os.path.join(home, "Desktop"), home):
            try:
                names = sorted(os.listdir(folder))
            except OSError:
                continue
            for n in names:
                p = os.path.join(folder, n)
                if not n.lower().endswith(".json") or not os.path.isfile(p) or os.path.getsize(p) > 20000:
                    continue
                try:
                    with open(p, encoding="utf-8") as f:
                        d = json.load(f)
                except (OSError, ValueError):
                    continue
                if isinstance(d, dict) and d.get("privateKey") and (d.get("name") or d.get("id")):
                    found.append({"path": p, "label": p.replace(home, "~", 1)})
        return found

    async def set_bot(self, name):
        s = _load_settings()
        s["bot"] = name if name in BOTS else "auto"
        _save_settings(s)
        return s

    async def act(self, bot, action, value=None, confirm=None):
        if bot not in _installed_bots():
            return {"ok": False, "message": f"{bot} isn't set up on this Deck."}
        body = {"action": action}
        if value is not None:
            body["value"] = value
        if confirm is not None:
            body["confirm"] = confirm
        status, reply = await asyncio.to_thread(_call, bot, "POST", "/api/action", body)
        if status == 0:
            return {"ok": False, "message": reply.get("error", "Couldn't reach the bot.")}
        out = {"ok": bool(reply.get("ok")), "message": reply.get("message") or reply.get("error", "")}
        if isinstance(reply.get("data"), dict):
            out["data"] = reply["data"]
        return out

    async def _main(self):
        decky.logger.info("Bot Panel loaded")

    async def _unload(self):
        decky.logger.info("Bot Panel unloaded")

    async def _uninstall(self):
        pass
