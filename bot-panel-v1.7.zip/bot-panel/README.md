# Bot Panel (Decky plugin)

Adds DeckBot or PumpBot to the Steam Deck **Quick Access** menu, so you can check and steer it in Game Mode.

**What it shows:** each bot's mode (📝 paper or 💵 live), whether it's running (🟢) or has stopped
checking the market (🟠), balance, today's result, open positions, the **Ready to go live?** report,
recent trades and recent activity. PumpBot also shows whether it's keeping the Deck awake (🌙), and the
panel warns you (🪫) when the Deck is on battery while PumpBot holds tokens.

**What you can do:** change risk level (🛡️ conservative, ⚖️ moderate, 🔥 aggressive), change trade size
(PumpBot), pause or resume one bot or all of them, go live (two confirmation screens that show your
settings and the paper verdict), switch back to paper, and sell everything and stop (asks first).

**🔑 Keys:** enter or replace Kraken keys and PumpBot's wallet keys with masked fields, or pick your
Coinbase `cdp_api_key.json` (found automatically in Downloads). Keys are checked before saving and only
shown afterwards as "✓ set (…ab12)". **🪄 Generate new wallet** creates a fresh PumpBot wallet and shows
the private key once so you can back it up.

**🔔 Pop-ups while gaming:** Steam notifications for buys, sells, a stalled bot and daily-limit hits,
even with Quick Access closed. Switch it off in the ⚙️ section.

**📂 Open positions** with live % change. Tap a PumpBot token to open it on pump.fun.

**🧰 Updates & backups:** install a newer bot zip from your Downloads with one tap, make an encrypted
backup (to an SD card, USB stick or Documents), or restore one.

**🌐 Open dashboard** opens the selected bot's full web dashboard in Steam's built-in browser, right in
Game Mode: charts, phone alerts, budgets, coins, the trade download and the full log.

## Requirements
- DeckBot or PumpBot installed and running on this Deck (it reads the panel the bot runs).
- Decky Loader.

## Install
Install the zip from Decky's settings (developer mode, install plugin from zip), then open Quick Access.
If both bots are installed, pick one in the first menu item.

The panel only listens on this Deck (127.0.0.1). The token is read from the bot's own data folder;
this plugin never sends it anywhere else.
